import React from "react";

export const Layout = (props) => <div>{props.children}</div>;
