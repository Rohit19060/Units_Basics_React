import React from "react";

function NoMatch() {
  return (
    <div>
      <h2>No Match</h2>
    </div>
  );
}
export default NoMatch;
